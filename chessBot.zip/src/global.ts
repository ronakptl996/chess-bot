declare var global: any;
export = global;
