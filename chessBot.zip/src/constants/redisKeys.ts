export = Object.freeze({
  TABLES: "TABLES",
  PLAYERS: "PLAYERS",
  QUEUE: "QUEUE",
});
