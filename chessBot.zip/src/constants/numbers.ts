export = Object.freeze({
  SEVEN: 7,
  FIVE: 5,
  TEN: 10,
  SIXTY: 60,
});
