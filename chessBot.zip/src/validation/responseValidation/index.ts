import * as joinResValidation from "./joinResVal";
import updateRoomValidate from "./updateResVal";

export { joinResValidation, updateRoomValidate };
