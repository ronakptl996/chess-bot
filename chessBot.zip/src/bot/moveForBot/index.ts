import botBlackRookMove from "./botBlackRookMove";
import botBlackKnightMove from "./botBlackKnightMove";
import botBlackBishopMove from "./botBlackBishopMove";
import botBlackQueenMove from "./botBlackQueenMove";
import botBlackKingMove from "./botBlackKingMove";
import botBlackPawnMove from "./botBlackPawnMove";

export {
  botBlackRookMove,
  botBlackKnightMove,
  botBlackBishopMove,
  botBlackQueenMove,
  botBlackKingMove,
  botBlackPawnMove,
};
