export = Object.freeze({
  TURN_DELAY_QUEUE: "turnDelayQueue",
  START_GAME_QUEUE: "startGameQueue",
  LOCK_IN_GAME_QUEUE: "lockInGameQueue",
  LEAVE_USER_GAME_QUEUE: "leaveUserGameQueue",
  BOT_TURN_TIMER: "botTurnTimer",
});
