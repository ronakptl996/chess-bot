import joinValidate from "./joinReqVal";
import updateValidate from "./updateVal";

export { joinValidate, updateValidate };
