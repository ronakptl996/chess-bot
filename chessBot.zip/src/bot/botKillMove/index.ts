import possibleBishopkillMove from "./possibleBishopKillMove";
import possibleKingKillMove from "./possibleKingKillMove";
import possibleKnightKillMove from "./possibleKnightKillMove";
import possiblePawnKillMove from "./possiblePawnKillMove";
import possibleQueenKillMove from "./possibleQueenKillMove";
import possibleRookKillMove from "./possibleRookKillMove";

export {
  possibleQueenKillMove,
  possiblePawnKillMove,
  possibleRookKillMove,
  possibleKnightKillMove,
  possibleBishopkillMove,
  possibleKingKillMove,
};
